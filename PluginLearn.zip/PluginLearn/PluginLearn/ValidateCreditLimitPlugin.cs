﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using PluginLearn.BusinessLogic;

namespace PluginLearn
{
    public class ValidateCreditLimitPlugin : IPlugin
    {

        public void Execute(IServiceProvider serviceProvider)
        {
            // Obtain the execution context from the service provider.
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));

            // Obtain the organization service reference for web service calls.
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            IOrganizationService service = serviceFactory.CreateOrganizationService(context.UserId);

            try
            {
                ValidateCreditLimit creditLimitHandler = new ValidateCreditLimit(context);
                creditLimitHandler.Execute_ValidateCreditLimit();
            }
            catch (Exception ex) {
                throw new InvalidPluginExecutionException(ex.Message);
            }
        }

    }
}