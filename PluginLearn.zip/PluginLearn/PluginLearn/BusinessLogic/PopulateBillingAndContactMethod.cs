﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace PluginLearn.BusinessLogic
{

    public class PopulateBillingAndContactMethod
    {
        private IPluginExecutionContext context;
        private IOrganizationService service;

        public PopulateBillingAndContactMethod(IPluginExecutionContext context, IOrganizationService _service)
        {
            this.context = context;
            this.service = _service;
        }

        public void Execute_PopulateBillingAndContactMethod()
        {
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity contact = (Entity)context.InputParameters["Target"];

                if (contact.Attributes.Contains("parentcustomerid"))
                {
                    EntityReference accountRef = contact.GetAttributeValue<EntityReference>("parentcustomerid");
                    Entity relatedAccount = service.Retrieve(accountRef.LogicalName, accountRef.Id,
                        new ColumnSet("transactioncurrencyid", "creditlimit", "creditonhold", "preferredcontactmethodcode"));

                    contact["creditlimit"] = relatedAccount.GetAttributeValue<Money>("creditlimit");
                    contact["transactioncurrencyid"] = relatedAccount.GetAttributeValue<EntityReference>("transactioncurrencyid");
                    contact["creditonhold"] = relatedAccount.GetAttributeValue<bool>("creditonhold");
                    contact["preferredcontactmethodcode"] = relatedAccount.GetAttributeValue<OptionSetValue>("preferredcontactmethodcode");
                }
            }
        }
    }
}
