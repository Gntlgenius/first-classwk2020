﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;

namespace PluginLearn.BusinessLogic
{
    public class ValidateCreditLimit
    {
        private  IPluginExecutionContext context;

        public ValidateCreditLimit(IPluginExecutionContext _context) {
            this.context = _context;
        }


        public void Execute_ValidateCreditLimit()
        {
            if (context.InputParameters.Contains("Target") && context.InputParameters["Target"] is Entity)
            {
                Entity contact = (Entity)context.InputParameters["Target"];
                decimal creditLimit = 0.00m;

                if (contact.Attributes.Contains("creditlimit"))
                {
                    creditLimit = contact.GetAttributeValue<Money>("creditlimit").Value;

                    if(creditLimit > 50.0m && (!contact.Attributes.Contains("parentcustomerid"))) 
                    {
                        throw new Exception("contact must belong to an organization to be able to have a credit limit above 50 pounds");
                    }
                }
            }
        }
    }
}
